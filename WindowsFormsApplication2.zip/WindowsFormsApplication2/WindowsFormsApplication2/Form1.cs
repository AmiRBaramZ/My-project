﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        int adad, m ,q,d;
        string c;
        private int charCount = 0;
        public Form1()
        {

            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Button adad = (Button)sender;
            label1.Text += adad.Text;
            ActiveControl = label1;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ActiveControl = label1;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (label1.Text != "")
            {
 label1.Text = "";
            }

            ActiveControl = label1;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (label1.Text != "")
            {
 int del = label1.Text.Length;
            label1.Text = label1.Text.Remove(--del);
            }
            ActiveControl = label1;
        }

        private void button13_Click(object sender, EventArgs e)
        {
           
            if (label1.Text != "")
            {
  adad = Convert.ToInt32(label1.Text);
            label1.Text = "";
            c = "+";
            }
            ActiveControl = label1;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (label1.Text != "")
            {
adad = Convert.ToInt32(label1.Text);
            label1.Text = "";
            c = "-";
            }
            ActiveControl = label1;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (label1.Text != "")
            {
adad = Convert.ToInt32(label1.Text);
            label1.Text = "";
            c = "*";
            }
            ActiveControl = label1;
        }

        private void button0_MouseHover(object sender, EventArgs e)
        {
            ActiveControl = label1;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            ActiveControl = label1;
        }

        private void button0_MouseHover_1(object sender, EventArgs e)
        {
          //  button1.BackColor = Color.Blue;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            ActiveControl = label1;
        }

        private void label1_Click_1(object sender, EventArgs e)
        {
            ActiveControl = label1;
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
          /*  if (charCount > 30)
               
            {
                label1.Text += "rn";

                charCount = 0;
            }

            else

            {
                label1.Text += e.KeyChar;

            }*/
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            ActiveControl = label1;
        }

        private void Form1_KeyDown_1(object sender, KeyEventArgs e)
        {
            ActiveControl = label1;
        /*    if(e.KeyCode == Keys.Enter)
            {
                label1.Text = "enter";
            }else if(e.KeyCode == Keys.NumPad0)
            {
                label1.Text = "000";
            }*/
        }

        private void label1_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {


            ActiveControl = label1;
         
             if (e.KeyCode == Keys.NumPad0)
            {
                label1.Text += "0";
            }
            else if (e.KeyCode == Keys.NumPad1)
            {
                label1.Text += "1";
            }
            else if (e.KeyCode == Keys.NumPad2)
            {
                label1.Text += "2";
            }
            else if (e.KeyCode == Keys.NumPad3)
            {
                label1.Text += "3";
            }
            else if (e.KeyCode == Keys.NumPad4)
            {
                label1.Text += "4";
            }
            else if (e.KeyCode == Keys.NumPad5)
            {
                label1.Text += "5";
            }
            else if (e.KeyCode == Keys.NumPad6)
            {
                label1.Text += "6";
            }
            else if (e.KeyCode == Keys.NumPad7)
            {
                label1.Text += "7";
            }
            else if (e.KeyCode == Keys.NumPad8)
            {
                label1.Text += "8";
            }
            else if (e.KeyCode == Keys.NumPad9)
            {
                label1.Text += "9";
            }
            else if (e.KeyCode == Keys.Subtract)
            {
                if (label1.Text != "")
                {
                    label1.Text = "-";
                    label1.Text = "";
                    c = "-";
                }

            }
            else if (e.KeyCode == Keys.Multiply)
            {
                if (label1.Text != "")
                {
                    label1.Text += "*";
                    label1.Text = "";
                    c = "*";
                }

            }
            else if (e.KeyCode == Keys.Divide)
            {
                if (label1.Text != "")
                {
                    label1.Text += "/";
                    label1.Text = "";
                    c = "/";
                }

            }
            else if (e.KeyCode == Keys.Add)
            {
                if (label1.Text != "")
                {
                    label1.Text = "";
                    c = "+";
                }

            }
            else if (e.KeyCode == Keys.Back)
            {
                if (label1.Text != "")

                {
                    int del = label1.Text.Length;
                    label1.Text = label1.Text.Remove(--del);
                }

            }
            else if (e.KeyCode == Keys.Delete)
            {
                if (label1.Text != "")
                {
                    label1.Text = "";
                }

            }
            else if (e.KeyCode == Keys.Enter)
            {
               m = Convert.ToInt32(label1.Text);
                switch (c)
                {
                    case "-":
                        q = adad - m;
                        break;
                    case "+":
                        q = adad + m;
                        break;
                    case "/":
                        q = adad / m;
                        break;
                    case "*":
                        q = adad * m;
                        break;
                    default:
                        break;
                }
                label1.Text = q.ToString();

            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (label1.Text != "")
            {
 adad = Convert.ToInt32(label1.Text);
            label1.Text = "";
            c = "/";
            }
            ActiveControl = label1;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (label1.Text != "")
            {
                m = Convert.ToInt32(label1.Text);
                switch (c)
                {
                    case "-":
                        q = adad - m;
                        break;
                    case "+":
                        q = adad + m;
                        break;
                    case "/":
                        q = adad / m;
                        break;
                    case "*":
                        q = adad * m;
                        break;
                    default:
                        break;
            }    
                label1.Text = q.ToString();

            }
        }
               
            
        }
    }

